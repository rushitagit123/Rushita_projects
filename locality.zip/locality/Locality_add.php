<?php
$addme=$_POST["addme"];
global $wpdb;
$table_name = $wpdb->prefix . "locality";
$table_name1 = $wpdb->prefix . "location";
if($_POST['submit']=="Add")
{
extract($_POST);

$wpdb->query("insert into $table_name(lid,State,people,electricity,batter_bank,solar_panel,inverter,batter_banke,solar_panele,invertere) values('','$State','$people','$electricity','$batter_bank','$solar_panel','$inverter','$batter_banke','$solar_panele','$invertere')");
header("Location:admin.php?page=Locality_list&info=insert");
exit;
} 
if($_POST['submit']=="Update")
{
extract($_POST);

$wpdb->query("update $table_name set State='$State',people='$people', electricity='$electricity' ,batter_bank='$batter_bank',solar_panel='$solar_panel',inverter='$inverter',batter_banke='$batter_banke',solar_panele='$solar_panele',invertere='$invertere' where lid=".$_GET['lid']);
header("Location:admin.php?page=Locality_list&info=update");
}
$btnsignup="Add";
	  if($_GET['lid']){
		  $getm=$wpdb->get_row("select * from $table_name where lid=".$_GET['lid']);
		if(count($getm) > 0)
		 {    $btnsignup="Update";
		 }
		else
		{    $btnsignup="Add";
		}	
	  }
?><div xmlns="http://www.w3.org/1999/xhtml" class="wrap nosubsub">
<div class="icon32" id="icon-edit"><br/></div>
<h2>Off-grid solar calculator</h2>
<div id="col-left">
	<div class="col-wrap">
		<div>
			<div class="form-wrap">
				<h3>Add Data</h3>
				<form class="validate" action="" method="post" id="addtag" enctype="multipart/form-data">
					<select name="State">
                    <option value="">Select State</option>
                    <?php
		$sql = "select DISTINCT State from ".$table_name1." order by pid desc";

		
		$getmresult=$wpdb->get_results($sql); 
		
      foreach ($getmresult as $key) {
		 $keyvalue=  $key->State;
		  $upvalue=  $getm->State;
		   $npeople=  $getm->people;
		  
	?>
   
    
  <option value="<?php echo $key->State; ?>" <?php if($keyvalue == $upvalue) { echo "selected"; } ?> ><?php echo $key->State; ?> </option>
		
<?php 
	 } ?>
     </select>
                       <div class="form-field">
						<label for="tag-slug">No of people</label>
                        <select name="people"  id="people">
                    <option value="">Select No of people </option>
                    <option value="1" <?php if($npeople == 1) { echo "selected";} ?>> 1</option> 
           <option value="2"  <?php if($npeople == 2) { echo "selected";} ?>> 2</option> 
           <option value="3"  <?php if($npeople == 3) { echo "selected";} ?>> 3</option> 
           <option value="4"  <?php if($npeople == 4) { echo "selected";} ?>> 4</option> 
           <option value="5"  <?php if($npeople == 5) { echo "selected";} ?>> 5+</option> 
                    </select>
						
					</div>
                    
                    <div class="form-field">
						<label for="tag-slug">kWH/D </label>
						<input type="text" size="40" value="<?php echo $getm->electricity; ?>" id="electricity" name="electricity"/>
					</div>
                     <div class="com"> <h2>MINI Off-grid solar system</h2></div>
                    <div class="form-field">
						<label for="tag-slug">Battery bank kWH</label>
						<input type="text" size="40" value="<?php echo $getm->batter_bank; ?>" id="batter_bank" name="batter_bank"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">Solar panels array kW </label>
						<input type="text" size="40" value="<?php echo $getm->solar_panel; ?>" id="solar_panel" name="solar_panel"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">Inverter size kW</label>
						<input type="text" size="40" value="<?php echo $getm->inverter; ?>" id="inverter" name="inverter"/>
					</div>
                   <div class="com"> <h2>MAXI Off-grid solar system</h2>
                  </div>
                    <div class="form-field">
						<label for="tag-slug">Battery bank kWH </label>
						<input type="text" size="40" value="<?php echo $getm->batter_banke; ?>" id="batter_banke" name="batter_banke"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">Solar panels array kW </label>
						<input type="text" size="40" value="<?php echo $getm->solar_panele; ?>" id="solar_panele" name="solar_panele"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">Inverter size kW</label>
						<input type="text" size="40" value="<?php echo $getm->invertere; ?>" id="invertere" name="invertere"/>
					</div>
					
                        
                        <div class="form-field submitclass">
						
						<input type="submit" size="40" value="<?php echo $btnsignup; ?>" id="submit" name="submit"/></div>
					
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<style>.ccleft label {
    float: left;
    margin-right: 2px;
    margin-top: -3px;
}.ccleft {
    float: left;
    width: 10%;
}
.submitclass{float:left; width:100%;}</style>