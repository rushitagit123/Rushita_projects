<?php
	global $wpdb;
	$table_name = $wpdb->prefix . "locality";
if(isset($_REQUEST['did']))
{
$delid=$_GET["did"];
$wpdb->query("delete from ".$table_name." where lid=".$delid);
header("Location:admin.php?page=myplug/muyplg.php&info=saved");

}
if($_GET['info']=='saved')
{
echo "<h2 align='center'>Delete Succesfully</h2>";
}

if($_GET['info']=='insert')
{
echo "<h2 align='center'>insert Succesfully</h2>";
}

if($_GET['infqo']=='update')
{
echo "<h2 align='center'>update Succesfully</h2>";
}

?>

<div class="wrap">
  <h2>List of Records<a class="button add-new-h2" href="admin.php?page=Locality_add&act=add">Add New</a></h2>
  <table class="wp-list-table widefat fixed" id="memberlist">
    <thead>
      <tr>
        <th><u>ID</u></th>
        <th><u>State</u></th>
         <th><u>Nomber of accupants </u></th>
        <th><u>kWH/D </u></th>
        <th><u>Battery bank kWH (Recomended Minimum) </u></th>
        <th><u>Solar panels array kW  (Recomended Minimum) </u></th>
        <th><u>Inverter size kW (Recomended Minimum) </u></th>
        <th><u>Battery bank kWH  (electrical house) </u></th>
        <th><u>Solar panels array kW (electrical house) </u></th>
        <th><u>Inverter size kW (electrical house) </u></th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php
		$sql = "select * from ".$table_name." order by lid desc";
		
		$getmresult=$wpdb->get_results($sql); 
		
      foreach ($getmresult as $key) {
	?>
      <tr>
        <td><?php echo $key->lid; ?></td>
        <td><?php echo $key->State; ?></td>
    
          <td width="50px"><?php echo $key->people; ?></td>
        <td width="50px"><?php echo $key->electricity; ?></td>
        <td width="50px"><?php echo $key->batter_bank; ?></td>
        <td width="50px"><?php echo $key->solar_panel; ?></td>
        <td width="50px"><?php echo $key->inverter; ?></td>
        <td width="50px"><?php echo $key->batter_banke; ?></td>
        <td width="50px"><?php echo $key->solar_panele; ?></td>
        <td width="50px"><?php echo $key->invertere; ?></td>
        <td><u><a href="admin.php?page=Locality_add&act=upd&lid=<?php echo $key->lid;?>">Edit</a></u></td>
        <td><u><a onclick="return confirm('Are you sure?')" href="admin.php?page=myplug/muyplg.php&info=del&did=<?php echo $key->lid;?>">Delete</a></u></td>
      </tr>
      <?php 
	 } ?>
    </tbody>
  </table>
</div>
