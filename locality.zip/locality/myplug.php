<?php
/*
Plugin Name: Locality/Postcode/state Search
Plugin URI: http://100up.com.au
Description: This plugin used for add edit delete and listing module at admin side.Also user can search records.
Version: 1.0
Author: Cloudweblabs
*/
$table_name = $wpdb->prefix . "location";

function addmyplug() {

	global $wpdb;

	$table_name = $wpdb->prefix . "location";

	$MSQL = "show tables like '$table_name'";

	if($wpdb->get_var($MSQL) != $table_name)
	{
	   $sql = "CREATE TABLE IF NOT EXISTS $table_name (
		  pid mediumint(9) NOT NULL AUTO_INCREMENT,
		  postcode varchar(255) NULL,
		  Locality varchar(255) NULL,
		  State varchar(255) NULL,
		  PRIMARY KEY pid (pid)
		) ";
		require_once(ABSPATH . "wp-admin/includes/upgrade.php");
		dbDelta($sql);
	}
	$table_name = $wpdb->prefix . "locality";

	$MSQL = "show tables like '$table_name'";

	if($wpdb->get_var($MSQL) != $table_name)
	{
	   $sql = "CREATE TABLE IF NOT EXISTS $table_name (
		  lid mediumint(9) NOT NULL AUTO_INCREMENT,
		  State varchar(255) NULL,
		   people varchar(255) NULL,
		   electricity varchar(255) NULL,
		    batter_bank varchar(255) NULL,
			 solar_panel varchar(255) NULL,
			  inverter varchar(255) NULL,
			   batter_banke varchar(255) NULL,
			    solar_panele varchar(255) NULL,
				 invertere varchar(255) NULL,
		  
		  PRIMARY KEY lid (lid)
		) ";
		require_once(ABSPATH . "wp-admin/includes/upgrade.php");
		dbDelta($sql);
	}
	
	$table_name = $wpdb->prefix . "formdata";

	$MSQL = "show tables like '$table_name'";

	if($wpdb->get_var($MSQL) != $table_name)
	{
	   $sql = "CREATE TABLE IF NOT EXISTS $table_name (
		  fid mediumint(9) NOT NULL AUTO_INCREMENT,
		  postcode varchar(255) NULL,
		   people varchar(255) NULL,
		   Name varchar(255) NULL,
		    email varchar(255) NULL,
			 Address varchar(255) NULL,
			  phone VARCHAR(15) NULL,
			   status  varchar(255) NULL,
			   Time_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		  PRIMARY KEY fid (fid)
		) ";
		require_once(ABSPATH . "wp-admin/includes/upgrade.php");
		dbDelta($sql);
	}
}

	/* Hook Plugin */
	register_activation_hook(__FILE__,'addmyplug');
	/* Creating Menus */
	function member_Menu()
	{
		/* Adding menus */
		add_menu_page(__('advertisement List'),'Postcode List', 8,'myplug/muyplg.php', 'postcod_list');
		add_submenu_page('myplug/muyplg.php', 'Add Postcode', 'Add Postcode', 8, 'postcod_add', 'postcod_add');
		add_submenu_page('myplug/muyplg.php', 'Locality list', 'Locality list', 8, 'Locality_list', 'Locality_list');
		add_submenu_page('myplug/muyplg.php', 'Add Locality', 'Add Locality', 8, 'Locality_add', 'Locality_add');
		add_submenu_page('myplug/muyplg.php', 'Quote list', 'Quote list', 8, 'quote_list', 'quote_list');

	}

add_action('admin_menu', 'member_Menu');
function postcod_list() {
	include "postcodelist.php";
}
function postcod_add() {
	include "postcode_add.php";
}
function Locality_list() {
	include "localitylist.php";
}
function Locality_add() {
	include "Locality_add.php";
}
function quote_list() {
	include "quote_list.php";
}
?>