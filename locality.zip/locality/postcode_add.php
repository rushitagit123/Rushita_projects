<?php
$addme=$_POST["addme"];
global $wpdb;
$table_name = $wpdb->prefix . "location";
if($_POST['submit']=="Add")
{
extract($_POST);

$wpdb->query("insert into $table_name(pid,postcode,Locality,State) values('','$postcode','$Locality','$State')");
header("Location:admin.php?page=myplug/muyplg.php&info=insert");
exit;
} 
if($_POST['submit']=="Update")
{
extract($_POST);

$wpdb->query("update $table_name set postcode='$postcode',Locality='$Locality' ,State='$State' where pid=".$_GET['pid']);
header("Location:admin.php?page=myplug/muyplg.php&info=update");
}
$btnsignup="Add";
	  if($_GET['pid']){
		  $getm=$wpdb->get_row("select * from $table_name where pid=".$_GET['pid']);
		if(count($getm) > 0)
		 {    $btnsignup="Update";
		 }
		else
		{    $btnsignup="Add";
		}	
	  }
?><div xmlns="http://www.w3.org/1999/xhtml" class="wrap nosubsub">
<div class="icon32" id="icon-edit"><br/></div>
<h2>Location</h2>
<div id="col-left">
	<div class="col-wrap">
		<div>
			<div class="form-wrap">
				<h3>Add Postcode/Locality/State</h3>
				<form class="validate" action="" method="post" id="addtag" enctype="multipart/form-data">
				
                     <div class="form-field">
						<label for="tag-slug">Postcode</label>
						<input type="text" size="40" value="<?php echo $getm->postcode; ?>" id="postcode" name="postcode" required="required"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">Locality</label>
						<input type="text" size="40" value="<?php echo $getm->Locality; ?>" id="Locality" name="Locality" required="required"/>
					</div>
                    <div class="form-field">
						<label for="tag-slug">State</label>
						<input type="text" size="40" value="<?php echo $getm->State; ?>" id="State" name="State" required="required"/>
					</div>
					
                        
                        <div class="form-field submitclass">
						
						<input type="submit" size="40" value="<?php echo $btnsignup; ?>" id="submit" name="submit"/></div>
					
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<style>.ccleft label {
    float: left;
    margin-right: 2px;
    margin-top: -3px;
}.ccleft {
    float: left;
    width: 10%;
}
.submitclass{float:left; width:100%;}</style>