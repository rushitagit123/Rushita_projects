<?php
	global $wpdb;
	$table_name = $wpdb->prefix . "location";
if(isset($_REQUEST['did']))
{
$delid=$_GET["did"];
$wpdb->query("delete from ".$table_name." where pid=".$delid);
header("Location:admin.php?page=myplug/muyplg.php&info=saved");

}
if($_GET['info']=='saved')
{
echo "<h2 align='center'>Delete Succesfully</h2>";
}

if($_GET['info']=='insert')
{
echo "<h2 align='center'>insert Succesfully</h2>";
}

if($_GET['infqo']=='
update')
{
echo "<h2 align='center'>update Succesfully</h2>";
}

?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>
<div class="wrap">
    <h2>List of Records<a class="button add-new-h2" href="admin.php?page=postcod_add&act=add">Add New</a></h2>
	 <table class="wp-list-table widefat fixed" id="memberlist">
		<thead>
			<tr>
				<th><u>ID</u></th>
				<th><u>Post code </u></th>
                <th><u>Locality </u></th>
                <th><u>State </u></th>
               
               	<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
<?php
		$sql = "select * from ".$table_name." order by pid";
		
		$getmresult=$wpdb->get_results($sql); 
		
      foreach ($getmresult as $key) {
	?>
			<tr>
				<td><?php echo $key->pid; ?></td>
				
                <td width="50px"><?php echo $key->postcode; ?></td>
                 <td width="50px"><?php echo $key->Locality; ?></td>
                  <td width="50px"><?php echo $key->State; ?></td>
				<td><u><a href="admin.php?page=postcod_add&act=upd&pid=<?php echo $key->pid;?>">Edit</a></u></td>
				<td><u><a onclick="return confirm('Are you sure?')" href="admin.php?page=myplug/muyplg.php&info=del&did=<?php echo $key->pid;?>">Delete</a></u></td>
			</tr>
<?php 
	 } ?>
	</tbody>
	</table>
</div>
<script>
jQuery(document).ready( function () {
    jQuery('#memberlist').DataTable();
} );
</script>