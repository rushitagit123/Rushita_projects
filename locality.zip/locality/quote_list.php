<?php
	global $wpdb;
	$table_name = $wpdb->prefix . "formdata";
?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>
<div class="wrap">
<button onclick="exportTableToExcel('memberlist')" style="float: right;width: auto;background: #000;color: #fff;padding: 5px 10px;border: 0;">Export Quote list</button>
    <h2>Quote List </h2>
	 <table class="wp-list-table widefat fixed" id="memberlist">
		<thead>
			<tr>
            <th>ID</th>
            <th>Locality</th>
            <th>People</th>
            <th>Name </th>
            <th>Email</th>
            <th>Adress </th>
            <th>Phone </th>
             <th>Date/Time</th>
             <th>Request Quote </th>
          </tr>
		</thead>
		<tbody>
          <?php
$sql = "SELECT * FROM ".$table_name." order by fid desc";
$getmresult=$wpdb->get_results($sql); 
		// print_r($getmresult);
		
       $i=1 ;
	   foreach ($getmresult as $key) {
	?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $key->postcode; ?></td>
          
            <td><?php echo $key->people; ?></td>
            <td><?php echo $key->Name; ?></td>
            <td><?php echo $key->email; ?></td>
            <td><?php echo $key->Address; ?></td>
            <td><?php echo $key->phone; ?></td>
            <td><?php echo $key->Time_date; ?></td>
              <td class="button"><?php echo $key->status; ?></td>
          </tr>
          <?php 
	$i++; } ?>
        </tbody>
	</table>
</div>
<script>
function exportTableToExcel(memberlist, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(memberlist);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'Quote-list.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
</script>
